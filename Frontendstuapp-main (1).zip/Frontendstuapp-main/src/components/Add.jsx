import { Button, TextField } from '@mui/material'
import React from 'react'

const Add = () => {
  return (
    <div>
        <h1>Add Student</h1>

        <TextField label='Name' variant='outlined' /><br /><br />
        <TextField label='Age' variant='outlined' /><br /><br />
        <TextField label='Department' variant='outlined' /><br /><br />
        <TextField label='Mark' variant='outlined' /><br /><br />
        
        <Button variant='contained'>Add Student</Button>
    </div>
  )
}

export default Add